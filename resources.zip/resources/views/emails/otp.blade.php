<!DOCTYPE html>
<html>
  <body>
    <p>Hello,</p>
    <p>Your OTP is: <strong>{{ $otp }}</strong></p>
    <p>Please do not share this code with anyone. It is valid for 10 minutes.</p>
    <p>Thanks,<br>Gymni Fitness Team</p>
  </body>
</html>
